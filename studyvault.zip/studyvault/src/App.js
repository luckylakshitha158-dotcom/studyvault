import { useState, useRef, useEffect, useMemo } from "react";

// ─── Syllabus Data ─────────────────────────────────────────────────────────────
const SYLLABUS = {
  ALP: {
    CBT1: {
      label: "CBT 1",
      topics: [
        "Mathematics – Number System, Decimals, Fractions, LCM, HCF, Ratio & Proportion, Percentage, Mensuration, Time & Work, Time & Distance, Simple & Compound Interest, Profit & Loss, Algebra, Geometry, Trigonometry, Statistics",
        "General Intelligence & Reasoning – Analogies, Alphabetical & Number Series, Coding & Decoding, Mathematical Operations, Relationships, Syllogism, Jumbling, Venn Diagram, Data Interpretation & Sufficiency, Conclusions & Decision Making",
        "General Science – Physics, Chemistry, Life Sciences (10th standard level)",
        "General Awareness – Current Affairs, Science & Technology, Sports, Culture, Personalities, Economics, Polity",
      ],
    },
    CBT2: {
      label: "CBT 2",
      topics: [
        "Mathematics – Advanced topics: Matrices, Determinants, Differential Calculus, Integral Calculus, Statistics & Probability, Vectors",
        "General Intelligence & Reasoning – Advanced Reasoning, Critical Thinking, Analytical Ability",
        "Basic Science & Engineering – Engineering Drawing, Units, Measurements, Mass, Weight, Density, Work Power Energy, Speed Velocity, Heat Temperature, Basic Electricity, Levers & Simple Machines, Occupational Safety & Health",
        "Relevant Trade – Trade-specific Technical Syllabus (Electrical, Electronics, Mechanical, etc.)",
      ],
    },
    CBT3: {
      label: "CBT 3",
      topics: [
        "Aptitude Test – Computer-based test for psycho aptitude",
        "Trade-specific Technical Knowledge – In-depth practical and theoretical knowledge of chosen trade",
        "Safety & Work Ethics – Workplace safety, Ethics, Discipline",
        "Psycho Test Parameters – Memory, Following Directions, Concentration, Perceptual Speed, Spatial Scanning",
      ],
    },
  },
  SSC: {
    Tier1: {
      label: "Tier 1",
      topics: [
        "General Intelligence & Reasoning – Analogies, Similarities & Differences, Spatial Visualization, Spatial Orientation, Problem Solving, Analysis, Judgment, Decision Making, Visual Memory, Discrimination, Observation, Relationship Concepts, Arithmetical Reasoning, Figural Classification, Arithmetic Number Series, Non-Verbal Series",
        "General Awareness – Current Events, India & its Neighbours, History, Culture, Geography, Economic Scene, General Polity, Indian Constitution, Scientific Research",
        "Quantitative Aptitude – Whole Numbers, Decimals, Fractions, Relationships between Numbers, Fundamental Arithmetical Operations, Percentages, Ratio & Proportion, Averages, Interest, Profit & Loss, Discount, Use of Tables & Graphs, Mensuration, Time & Distance, Ratio & Time, Time & Work",
        "English Comprehension – Basics of English Language, Vocabulary, Grammar, Sentence Structure, Synonyms, Antonyms, Correct Usage of Words",
      ],
    },
    Tier2: {
      label: "Tier 2",
      topics: [
        "Paper 1 – Quantitative Abilities: Advanced Mathematics, Data Interpretation, Statistics",
        "Paper 2 – English Language & Comprehension: Reading Comprehension, Fill in the Blanks, Spellings, Phrases & Idioms, One-Word Substitution, Active/Passive Voice, Reported Speech, Shuffling of Sentences",
        "Paper 3 (for JSO) – Statistics: Collection & Representation of Data, Measure of Central Tendency, Dispersion, Moments, Skewness & Kurtosis, Correlation & Regression, Probability Theory, Random Variable & Probability Distributions, Sampling Theory, Statistical Inference, Analysis of Variance, Time Series Analysis, Index Numbers",
        "Paper 4 (for AAO) – General Studies (Finance & Economics): Finance & Accounts, Economics & Governance",
      ],
    },
  },
};

// ─── Theme Tokens ──────────────────────────────────────────────────────────────
const DARK = {
  bg: "#0a0f1e", card: "#111827", cardBorder: "#1e293b",
  accent: "#f59e0b", accent2: "#06b6d4", text: "#f1f5f9",
  muted: "#94a3b8", success: "#10b981", inputBg: "#070c18",
  progressBg: "#1e293b", shadow: "0 4px 24px rgba(0,0,0,0.5)",
  glow1: "rgba(245,158,11,0.07)", glow2: "rgba(6,182,212,0.07)",
};
const LIGHT = {
  bg: "#f0f4ff", card: "#ffffff", cardBorder: "#d1daf5",
  accent: "#d97706", accent2: "#0891b2", text: "#0f172a",
  muted: "#64748b", success: "#059669", inputBg: "#e8eeff",
  progressBg: "#d1daf5", shadow: "0 4px 24px rgba(0,0,0,0.1)",
  glow1: "rgba(217,119,6,0.08)", glow2: "rgba(8,145,178,0.08)",
};

// ─── localStorage helpers ─────────────────────────────────────────────────────
const ls = {
  get: (k, def = null) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch { return def; } },
  set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

// ─── Progress helpers ─────────────────────────────────────────────────────────
function getProgress() { return ls.get("sv_progress", {}); }
function setProgress(p) { ls.set("sv_progress", p); }
function markDone(exam, stage, idx, val) {
  const p = getProgress();
  const key = `${exam}_${stage}_${idx}`;
  if (val) p[key] = true; else delete p[key];
  setProgress(p);
  return p;
}
function isDone(p, exam, stage, idx) { return !!p[`${exam}_${stage}_${idx}`]; }
function stageProgress(p, exam, stage) {
  const total = SYLLABUS[exam][stage].topics.length;
  const done = SYLLABUS[exam][stage].topics.filter((_, i) => isDone(p, exam, stage, i)).length;
  return { done, total, pct: total ? Math.round((done / total) * 100) : 0 };
}
function examProgress(p, exam) {
  const stages = Object.keys(SYLLABUS[exam]);
  let done = 0, total = 0;
  stages.forEach(s => { const sp = stageProgress(p, exam, s); done += sp.done; total += sp.total; });
  return { done, total, pct: total ? Math.round((done / total) * 100) : 0 };
}

// ─── ProgressBar ──────────────────────────────────────────────────────────────
function ProgressBar({ pct, color, height = 8, label }) {
  return (
    <div style={{ width: "100%" }}>
      {label && <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
        <span style={{ fontSize: "0.78rem" }}>{label}</span>
        <span style={{ fontSize: "0.78rem", fontWeight: 700, color }}>{pct}%</span>
      </div>}
      <div style={{ background: "rgba(128,128,128,0.18)", borderRadius: 99, height, overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: color, borderRadius: 99, transition: "width 0.4s ease" }} />
      </div>
    </div>
  );
}

// ─── Greeting Page ────────────────────────────────────────────────────────────
function GreetingPage({ onEnter, C }) {
  const [hov, setHov] = useState(false);
  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "2rem", textAlign: "center" }}>
      <span style={{ fontSize: "3.5rem", marginBottom: "1.2rem", display: "block" }}>🚂</span>
      <h1 style={{ fontSize: "clamp(2.2rem,6vw,4rem)", fontWeight: 700, letterSpacing: "-1px", color: C.accent, marginBottom: "0.5rem", lineHeight: 1.1 }}>
        Welcome, Aspirant!
      </h1>
      <p style={{ fontSize: "clamp(1rem,2.5vw,1.25rem)", color: C.muted, maxWidth: 520, lineHeight: 1.75, marginBottom: "0.7rem" }}>
        Your personal study companion for <strong style={{ color: C.text }}>RRB ALP</strong> & <strong style={{ color: C.text }}>SSC</strong> examinations.
      </p>
      <p style={{ fontSize: "0.95rem", color: C.muted, marginBottom: "2.5rem" }}>
        Organize syllabus · Upload PDFs · Save links · Track progress
      </p>
      <button
        onClick={onEnter}
        onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
        style={{ background: C.accent, color: "#fff", border: "none", borderRadius: 10, padding: "0.9rem 2.5rem", fontSize: "1.1rem", fontWeight: 700, cursor: "pointer", boxShadow: hov ? `0 0 36px ${C.accent}88` : `0 0 20px ${C.accent}44`, transform: hov ? "scale(1.06)" : "scale(1)", transition: "all 0.18s" }}>
        Let's Begin →
      </button>
    </div>
  );
}

// ─── Breadcrumb ───────────────────────────────────────────────────────────────
function Breadcrumb({ crumbs, onCrumbClick, C }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "1.5rem", flexWrap: "wrap" }}>
      {crumbs.map((c, i) => (
        <span key={i} style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
          {i < crumbs.length - 1
            ? <button onClick={() => onCrumbClick(i)} style={{ background: "none", border: "none", color: C.accent2, cursor: "pointer", fontSize: "0.88rem", padding: 0, textDecoration: "underline", fontFamily: "inherit" }}>{c}</button>
            : <span style={{ color: C.muted, fontSize: "0.88rem" }}>{c}</span>}
          {i < crumbs.length - 1 && <span style={{ color: C.muted, fontSize: "0.82rem" }}>›</span>}
        </span>
      ))}
    </div>
  );
}

// ─── Choice Grid ──────────────────────────────────────────────────────────────
function ChoiceGrid({ items, onSelect, accent, C, progress }) {
  const [hov, setHov] = useState(null);
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: "1rem", maxWidth: 680, margin: "0 auto" }}>
      {items.map(({ key, label, icon }) => {
        const pr = progress?.[key];
        return (
          <button key={key} onClick={() => onSelect(key)}
            onMouseEnter={() => setHov(key)} onMouseLeave={() => setHov(null)}
            style={{ background: hov === key ? accent : C.card, border: `2px solid ${hov === key ? accent : C.cardBorder}`, borderRadius: 14, padding: "1.4rem 1rem", cursor: "pointer", color: hov === key ? "#fff" : C.text, fontSize: "1.05rem", fontWeight: 700, fontFamily: "inherit", transition: "all 0.18s", boxShadow: hov === key ? `0 0 20px ${accent}55` : C.shadow, display: "flex", flexDirection: "column", alignItems: "center", gap: "0.5rem" }}>
            {icon && <span style={{ fontSize: "2rem" }}>{icon}</span>}
            {label}
            {pr && (
              <div style={{ width: "100%", marginTop: "0.4rem" }}>
                <ProgressBar pct={pr.pct} color={hov === key ? "#fff" : accent} height={5} />
                <span style={{ fontSize: "0.7rem", color: hov === key ? "#ffffffcc" : C.muted, marginTop: 3, display: "block" }}>{pr.done}/{pr.total} done</span>
              </div>
            )}
          </button>
        );
      })}
    </div>
  );
}

// ─── Search Bar ───────────────────────────────────────────────────────────────
function SearchBar({ value, onChange, C }) {
  return (
    <div style={{ position: "relative", marginBottom: "1.2rem" }}>
      <span style={{ position: "absolute", left: "0.75rem", top: "50%", transform: "translateY(-50%)", color: C.muted, fontSize: "1rem", pointerEvents: "none" }}>🔍</span>
      <input
        value={value} onChange={e => onChange(e.target.value)}
        placeholder="Search topics..."
        style={{ width: "100%", background: C.inputBg, border: `1.5px solid ${C.cardBorder}`, borderRadius: 9, padding: "0.6rem 0.9rem 0.6rem 2.2rem", color: C.text, fontFamily: "inherit", fontSize: "0.95rem", outline: "none", boxSizing: "border-box", transition: "border-color 0.15s" }}
        onFocus={e => e.target.style.borderColor = C.accent2}
        onBlur={e => e.target.style.borderColor = C.cardBorder}
      />
      {value && <button onClick={() => onChange("")} style={{ position: "absolute", right: "0.7rem", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: C.muted, cursor: "pointer", fontSize: "1rem" }}>✕</button>}
    </div>
  );
}

// ─── Topics Page ─────────────────────────────────────────────────────────────
function TopicsPage({ exam, stage, onSelectTopic, selectedTopic, C, progress, onToggleDone }) {
  const [search, setSearch] = useState("");
  const topics = SYLLABUS[exam][stage].topics;
  const filtered = useMemo(() =>
    topics.map((t, i) => ({ t, i })).filter(({ t }) => t.toLowerCase().includes(search.toLowerCase())),
    [topics, search]);

  const sp = stageProgress(progress, exam, stage);

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "0.5rem", marginBottom: "0.8rem" }}>
        <div>
          <h2 style={{ fontSize: "1.4rem", color: C.accent, marginBottom: "0.2rem" }}>Syllabus Topics</h2>
          <p style={{ color: C.muted, fontSize: "0.85rem" }}>Select a topic to manage your resources. ✓ = completed</p>
        </div>
        <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, padding: "0.5rem 1rem", minWidth: 140 }}>
          <ProgressBar pct={sp.pct} color={C.accent} height={7} label={`Progress: ${sp.done}/${sp.total}`} />
        </div>
      </div>
      <SearchBar value={search} onChange={setSearch} C={C} />
      {filtered.length === 0 && <p style={{ color: C.muted, textAlign: "center", padding: "1.5rem" }}>No topics match "{search}"</p>}
      <div style={{ display: "flex", flexDirection: "column", gap: "0.7rem" }}>
        {filtered.map(({ t, i }) => {
          const done = isDone(progress, exam, stage, i);
          const isSelected = selectedTopic === i;
          return (
            <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: "0.6rem" }}>
              <button
                onClick={() => onToggleDone(i, !done)}
                title={done ? "Mark incomplete" : "Mark complete"}
                style={{ flexShrink: 0, marginTop: "0.9rem", width: 22, height: 22, borderRadius: 6, border: `2px solid ${done ? C.success : C.cardBorder}`, background: done ? C.success : "transparent", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.15s" }}>
                {done && <span style={{ color: "#fff", fontSize: "0.75rem", fontWeight: 700 }}>✓</span>}
              </button>
              <button
                onClick={() => onSelectTopic(i)}
                style={{ flex: 1, background: isSelected ? `${C.accent}18` : done ? `${C.success}0d` : C.card, border: `2px solid ${isSelected ? C.accent : done ? C.success : C.cardBorder}`, borderLeft: `5px solid ${isSelected ? C.accent : done ? C.success : "transparent"}`, borderRadius: 10, padding: "0.85rem 1rem", cursor: "pointer", color: C.text, fontFamily: "inherit", fontSize: "0.93rem", textAlign: "left", transition: "all 0.15s", opacity: done && !isSelected ? 0.7 : 1 }}>
                <span style={{ color: isSelected ? C.accent : C.muted, fontWeight: 700, marginRight: "0.5rem" }}>{i + 1}.</span>
                {t}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Resource Manager ─────────────────────────────────────────────────────────
function ResourceManager({ exam, stage, topicIdx, C }) {
  const topic = SYLLABUS[exam][stage].topics[topicIdx];
  const shortName = topic.split("–")[0].trim();
  const storageKey = `resources_${exam}_${stage}_${topicIdx}`;
  const [resources, setResources] = useState(() => ls.get(storageKey, []));
  const [linkInput, setLinkInput] = useState("");
  const [noteInput, setNoteInput] = useState("");
  const [tab, setTab] = useState("pdf");
  const [search, setSearch] = useState("");
  const fileRef = useRef();

  const save = (r) => { setResources(r); ls.set(storageKey, r); };
  const handleFileUpload = (e) => {
    const newItems = Array.from(e.target.files).map(f => ({ type: "pdf", name: f.name, size: (f.size / 1024).toFixed(1) + " KB", date: new Date().toLocaleDateString() }));
    save([...resources, ...newItems]);
    fileRef.current.value = "";
  };
  const addLink = () => { if (!linkInput.trim()) return; save([...resources, { type: "link", url: linkInput.trim(), date: new Date().toLocaleDateString() }]); setLinkInput(""); };
  const addNote = () => { if (!noteInput.trim()) return; save([...resources, { type: "note", text: noteInput.trim(), date: new Date().toLocaleDateString() }]); setNoteInput(""); };
  const remove = (idx) => save(resources.filter((_, i) => i !== idx));

  const byType = (t) => resources.filter((r, i) => r.type === t && (search === "" || (r.name || r.url || r.text || "").toLowerCase().includes(search.toLowerCase()))).map((r) => ({ r, idx: resources.indexOf(r) }));

  const tabStyle = (t) => ({
    background: tab === t ? C.accent : "transparent",
    color: tab === t ? "#fff" : C.muted,
    border: `1.5px solid ${tab === t ? C.accent : C.cardBorder}`,
    borderRadius: 7, padding: "0.42rem 1rem", cursor: "pointer",
    fontFamily: "inherit", fontSize: "0.88rem", fontWeight: 600, transition: "all 0.15s",
  });

  const counts = { pdf: resources.filter(r => r.type === "pdf").length, link: resources.filter(r => r.type === "link").length, note: resources.filter(r => r.type === "note").length };

  return (
    <div style={{ background: C.card, border: `1.5px solid ${C.cardBorder}`, borderRadius: 14, padding: "1.4rem", marginTop: "1.4rem", boxShadow: C.shadow }}>
      <h3 style={{ color: C.accent, marginBottom: "0.25rem", fontSize: "1.05rem" }}>📂 Resources — <span style={{ color: C.text }}>{shortName}</span></h3>
      <p style={{ color: C.muted, fontSize: "0.82rem", marginBottom: "1rem" }}>All resources saved locally on your device.</p>

      <SearchBar value={search} onChange={setSearch} C={C} />

      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1.1rem", flexWrap: "wrap" }}>
        <button style={tabStyle("pdf")} onClick={() => setTab("pdf")}>📄 PDFs ({counts.pdf})</button>
        <button style={tabStyle("link")} onClick={() => setTab("link")}>🔗 Links ({counts.link})</button>
        <button style={tabStyle("note")} onClick={() => setTab("note")}>📝 Notes ({counts.note})</button>
      </div>

      {tab === "pdf" && (
        <div>
          <input ref={fileRef} type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.txt" multiple onChange={handleFileUpload} style={{ display: "none" }} id="file-upload" />
          <label htmlFor="file-upload" style={{ display: "inline-block", background: C.accent2, color: "#fff", borderRadius: 8, padding: "0.55rem 1.3rem", cursor: "pointer", fontWeight: 700, fontSize: "0.92rem", marginBottom: "0.9rem" }}>+ Upload Files</label>
          {byType("pdf").length === 0
            ? <p style={{ color: C.muted, fontSize: "0.88rem" }}>{search ? "No matches." : "No files uploaded yet."}</p>
            : <div style={{ display: "flex", flexDirection: "column", gap: "0.55rem" }}>
              {byType("pdf").map(({ r, idx }) => (
                <div key={idx} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: C.inputBg, borderRadius: 8, padding: "0.65rem 1rem" }}>
                  <span style={{ fontSize: "0.9rem" }}>📄 <strong>{r.name}</strong> <span style={{ color: C.muted, fontSize: "0.78rem" }}>({r.size}) · {r.date}</span></span>
                  <button onClick={() => remove(idx)} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: "1rem" }}>✕</button>
                </div>
              ))}
            </div>}
        </div>
      )}

      {tab === "link" && (
        <div>
          <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.9rem", flexWrap: "wrap" }}>
            <input value={linkInput} onChange={e => setLinkInput(e.target.value)} placeholder="Paste URL here..." onKeyDown={e => e.key === "Enter" && addLink()}
              style={{ flex: 1, minWidth: 180, background: C.inputBg, border: `1.5px solid ${C.cardBorder}`, borderRadius: 7, padding: "0.52rem 0.85rem", color: C.text, fontFamily: "inherit", fontSize: "0.92rem", outline: "none" }} />
            <button onClick={addLink} style={{ background: C.accent2, color: "#fff", border: "none", borderRadius: 7, padding: "0.52rem 1.1rem", cursor: "pointer", fontWeight: 700 }}>Add</button>
          </div>
          {byType("link").length === 0
            ? <p style={{ color: C.muted, fontSize: "0.88rem" }}>{search ? "No matches." : "No links added yet."}</p>
            : <div style={{ display: "flex", flexDirection: "column", gap: "0.55rem" }}>
              {byType("link").map(({ r, idx }) => (
                <div key={idx} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: C.inputBg, borderRadius: 8, padding: "0.65rem 1rem", gap: "0.5rem" }}>
                  <a href={r.url} target="_blank" rel="noopener noreferrer" style={{ color: C.accent2, wordBreak: "break-all", fontSize: "0.88rem" }}>🔗 {r.url}</a>
                  <button onClick={() => remove(idx)} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: "1rem", flexShrink: 0 }}>✕</button>
                </div>
              ))}
            </div>}
        </div>
      )}

      {tab === "note" && (
        <div>
          <textarea value={noteInput} onChange={e => setNoteInput(e.target.value)} placeholder="Write a note..." rows={3}
            style={{ width: "100%", background: C.inputBg, border: `1.5px solid ${C.cardBorder}`, borderRadius: 7, padding: "0.52rem 0.85rem", color: C.text, fontFamily: "inherit", fontSize: "0.92rem", outline: "none", resize: "vertical", marginBottom: "0.5rem", boxSizing: "border-box" }} />
          <button onClick={addNote} style={{ background: C.success, color: "#fff", border: "none", borderRadius: 7, padding: "0.52rem 1.1rem", cursor: "pointer", fontWeight: 700, marginBottom: "0.9rem" }}>Save Note</button>
          {byType("note").length === 0
            ? <p style={{ color: C.muted, fontSize: "0.88rem" }}>{search ? "No matches." : "No notes yet."}</p>
            : <div style={{ display: "flex", flexDirection: "column", gap: "0.55rem" }}>
              {byType("note").map(({ r, idx }) => (
                <div key={idx} style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", background: C.inputBg, borderRadius: 8, padding: "0.65rem 1rem", gap: "0.5rem" }}>
                  <span style={{ fontSize: "0.88rem", whiteSpace: "pre-wrap", color: C.text }}>📝 {r.text} <span style={{ color: C.muted, fontSize: "0.76rem" }}>· {r.date}</span></span>
                  <button onClick={() => remove(idx)} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: "1rem", flexShrink: 0 }}>✕</button>
                </div>
              ))}
            </div>}
        </div>
      )}
    </div>
  );
}

// ─── Overall Dashboard ────────────────────────────────────────────────────────
function Dashboard({ C, progress }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1rem", marginBottom: "2rem" }}>
      {["ALP", "SSC"].map(exam => {
        const ep = examProgress(progress, exam);
        const stagesData = Object.keys(SYLLABUS[exam]).map(s => ({ s, ...stageProgress(progress, exam, s) }));
        return (
          <div key={exam} style={{ background: C.card, border: `1.5px solid ${C.cardBorder}`, borderRadius: 14, padding: "1.1rem 1.2rem", boxShadow: C.shadow }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.7rem" }}>
              <span style={{ fontWeight: 700, fontSize: "1.05rem" }}>{exam === "ALP" ? "🚆 RRB ALP" : "🏛️ SSC"}</span>
              <span style={{ fontSize: "0.78rem", fontWeight: 700, color: ep.pct === 100 ? C.success : C.accent, background: `${ep.pct === 100 ? C.success : C.accent}18`, borderRadius: 99, padding: "0.15rem 0.55rem" }}>{ep.pct}%</span>
            </div>
            <ProgressBar pct={ep.pct} color={exam === "ALP" ? C.accent : C.accent2} height={8} />
            <div style={{ marginTop: "0.8rem", display: "flex", flexDirection: "column", gap: "0.3rem" }}>
              {stagesData.map(({ s, done, total, pct }) => (
                <div key={s} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: "0.8rem" }}>
                  <span style={{ color: C.muted }}>{SYLLABUS[exam][s].label}</span>
                  <span style={{ color: pct === 100 ? C.success : C.text, fontWeight: 600 }}>{done}/{total}</span>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("greeting");
  const [exam, setExam] = useState(null);
  const [stage, setStage] = useState(null);
  const [topicIdx, setTopicIdx] = useState(null);
  const [darkMode, setDarkMode] = useState(() => ls.get("sv_dark", true));
  const [progress, setProgressState] = useState(getProgress);

  const C = darkMode ? DARK : LIGHT;

  useEffect(() => { ls.set("sv_dark", darkMode); }, [darkMode]);

  const handleToggleDone = (idx, val) => {
    const newP = markDone(exam, stage, idx, val);
    setProgressState({ ...newP });
  };

  const alpStages = [
    { key: "CBT1", label: "CBT 1", icon: "1️⃣" },
    { key: "CBT2", label: "CBT 2", icon: "2️⃣" },
    { key: "CBT3", label: "CBT 3", icon: "3️⃣" },
  ];
  const sscStages = [
    { key: "Tier1", label: "Tier 1", icon: "🥇" },
    { key: "Tier2", label: "Tier 2", icon: "🥈" },
  ];

  const crumbs = ["Home"];
  if (exam) crumbs.push(exam === "ALP" ? "RRB ALP" : "SSC");
  if (stage) crumbs.push(SYLLABUS[exam][stage].label);
  if (topicIdx !== null) crumbs.push(SYLLABUS[exam][stage].topics[topicIdx].split("–")[0].trim());

  const onCrumbClick = (idx) => {
    if (idx === 0) { setExam(null); setStage(null); setTopicIdx(null); }
    if (idx === 1) { setStage(null); setTopicIdx(null); }
    if (idx === 2) { setTopicIdx(null); }
  };

  const accentForExam = exam === "ALP" ? C.accent : C.accent2;

  const appStyle = {
    minHeight: "100vh",
    background: C.bg,
    fontFamily: "'Georgia', 'Times New Roman', serif",
    color: C.text,
    position: "relative",
    transition: "background 0.3s, color 0.3s",
  };

  const bgGlow = {
    position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
    background: `radial-gradient(ellipse at 20% 20%, ${C.glow1} 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, ${C.glow2} 0%, transparent 55%)`,
    pointerEvents: "none", zIndex: 0,
  };

  if (page === "greeting") return (
    <div style={appStyle}>
      <div style={bgGlow} />
      {/* Theme toggle on greeting page */}
      <div style={{ position: "fixed", top: "1rem", right: "1rem", zIndex: 99 }}>
        <button onClick={() => setDarkMode(!darkMode)}
          style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 99, padding: "0.35rem 0.9rem", cursor: "pointer", fontSize: "1rem", color: C.text, fontFamily: "inherit" }}>
          {darkMode ? "☀️ Light" : "🌙 Dark"}
        </button>
      </div>
      <div style={{ position: "relative", zIndex: 1 }}>
        <GreetingPage onEnter={() => setPage("main")} C={C} />
      </div>
    </div>
  );

  const stageProgressMap = exam
    ? Object.fromEntries((exam === "ALP" ? alpStages : sscStages).map(({ key }) => [key, stageProgress(progress, exam, key)]))
    : null;

  return (
    <div style={appStyle}>
      <div style={bgGlow} />
      <div style={{ position: "relative", zIndex: 1, maxWidth: 880, margin: "0 auto", padding: "1.5rem 1.2rem 3rem" }}>

        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1.2rem", flexWrap: "wrap", gap: "0.5rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.6rem" }}>
            <span style={{ fontSize: "1.5rem" }}>🚂</span>
            <span style={{ fontSize: "1.15rem", fontWeight: 700, color: C.accent }}>StudyVault</span>
          </div>
          <div style={{ display: "flex", gap: "0.6rem", flexWrap: "wrap" }}>
            <button onClick={() => setDarkMode(!darkMode)}
              style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 7, padding: "0.3rem 0.8rem", cursor: "pointer", color: C.text, fontFamily: "inherit", fontSize: "0.85rem" }}>
              {darkMode ? "☀️ Light" : "🌙 Dark"}
            </button>
            <button onClick={() => setPage("greeting")}
              style={{ background: "none", border: `1px solid ${C.cardBorder}`, borderRadius: 7, color: C.muted, cursor: "pointer", padding: "0.3rem 0.8rem", fontSize: "0.85rem", fontFamily: "inherit" }}>
              ← Home
            </button>
          </div>
        </div>

        {/* Breadcrumb */}
        {exam && <Breadcrumb crumbs={crumbs} onCrumbClick={onCrumbClick} C={C} />}

        {/* Step 1: Dashboard + Exam Select */}
        {!exam && (
          <div>
            <Dashboard C={C} progress={progress} />
            <div style={{ textAlign: "center" }}>
              <h2 style={{ fontSize: "1.7rem", marginBottom: "0.4rem" }}>Choose Your Exam</h2>
              <p style={{ color: C.muted, marginBottom: "1.8rem", fontSize: "0.95rem" }}>Select the exam you're preparing for.</p>
              <ChoiceGrid
                items={[{ key: "ALP", label: "RRB ALP", icon: "🚆" }, { key: "SSC", label: "SSC", icon: "🏛️" }]}
                onSelect={(k) => { setExam(k); setStage(null); setTopicIdx(null); }}
                accent={C.accent} C={C}
                progress={{ ALP: examProgress(progress, "ALP"), SSC: examProgress(progress, "SSC") }}
              />
            </div>
          </div>
        )}

        {/* Step 2: Stage Select */}
        {exam && !stage && (
          <div style={{ textAlign: "center" }}>
            <h2 style={{ fontSize: "1.7rem", marginBottom: "0.4rem", color: accentForExam }}>{exam === "ALP" ? "🚆 RRB ALP" : "🏛️ SSC"}</h2>
            <p style={{ color: C.muted, marginBottom: "1.8rem", fontSize: "0.95rem" }}>Select the stage you want to study.</p>
            <ChoiceGrid
              items={exam === "ALP" ? alpStages : sscStages}
              onSelect={(k) => { setStage(k); setTopicIdx(null); }}
              accent={accentForExam} C={C}
              progress={stageProgressMap}
            />
          </div>
        )}

        {/* Step 3: Topics + Resources */}
        {exam && stage && (
          <div>
            <h2 style={{ fontSize: "1.4rem", marginBottom: "0.2rem", color: accentForExam }}>
              {exam} — {SYLLABUS[exam][stage].label}
            </h2>
            <p style={{ color: C.muted, marginBottom: "1.2rem", fontSize: "0.85rem" }}>Tick the checkbox to mark a topic as complete.</p>
            <TopicsPage
              exam={exam} stage={stage}
              onSelectTopic={setTopicIdx} selectedTopic={topicIdx}
              C={C} progress={progress}
              onToggleDone={handleToggleDone}
            />
            {topicIdx !== null && <ResourceManager exam={exam} stage={stage} topicIdx={topicIdx} C={C} />}
          </div>
        )}

      </div>
    </div>
  );
}
